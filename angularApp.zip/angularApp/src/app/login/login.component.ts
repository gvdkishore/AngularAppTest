import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
   public userName = '';
   public passWord = '';
  constructor(router: Router) { }

  ngOnInit(): void {
  }
  // showMainPage () {
  //   if (this.userName === 'admin' && this.passWord === 'admin') {
  //     this.
  //   }
  // }

}
