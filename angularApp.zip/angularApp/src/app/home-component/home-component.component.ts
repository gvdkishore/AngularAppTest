import { Component, OnInit } from '@angular/core';
import { SideBarService } from '../services/side-bar.service'
import { NgxSpinnerService } from "ngx-spinner";
import { Observable } from 'rxjs';
@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.scss']
})
export class HomeComponentComponent implements OnInit {
  moviesData: any;
  constructor(private service: SideBarService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
      this.service.getJsonData().subscribe(data => {
        this.moviesData = data
        console.log(this.moviesData)
      })
  }
  
}
